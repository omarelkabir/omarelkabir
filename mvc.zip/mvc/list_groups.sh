#!/bin/bash
rm group.txt
sudo samba-tool group list > groups.txt
