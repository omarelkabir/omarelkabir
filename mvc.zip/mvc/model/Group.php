<?php
class Group {
	public $groupname;

	public function __construct($groupname)
    {
	$this->groupname = $groupname;
    }
}
 
?>
